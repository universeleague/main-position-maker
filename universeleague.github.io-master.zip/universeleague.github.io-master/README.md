A personal ranker that allows you to rank and sort your own Top 7 for SBS Global Surival Show 'Universe League', the second season of 'Universe Ticket'. It currently has functionality for adding and removing trainees on the table through click, sorting them on the ranking itself through drag & drop, and activating filters that show which contestants have been eliminated or currently hold a top 7 position. It is also possible to save a link of your current ranking to revisit it as the episodes progress. 

![Screenshot](screenshot.png)
